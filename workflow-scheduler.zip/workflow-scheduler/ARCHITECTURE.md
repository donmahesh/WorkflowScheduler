# Architecture notes: production evolution

This document captures how the current implementation would evolve to production.
It directly addresses the exercise's follow-up discussion topics.

---

## 1. Making `claimRunnableSteps` safe across multiple application instances

The current implementation uses in-process `ReentrantLock`s per run. That is
sufficient for a single JVM but not across horizontally scaled instances.

Two viable patterns, each with trade-offs:

### a) Database row-level locking (recommended default)

Move step state into a relational table. Use `SELECT ... FOR UPDATE SKIP LOCKED`
(Postgres, Oracle, MySQL 8+) to atomically claim rows:

```sql
-- Pseudocode: single-statement claim with ordering
WITH claimed AS (
    SELECT run_id, step_id
    FROM step_run
    WHERE run_id = :runId
      AND status = 'PENDING'
      AND NOT EXISTS (
          SELECT 1 FROM step_run d
          WHERE d.run_id = :runId
            AND d.step_id = ANY(step_run.dependency_ids)
            AND d.status != 'SUCCEEDED'
      )
    ORDER BY priority DESC, step_id ASC
    LIMIT :maxCount
    FOR UPDATE SKIP LOCKED
)
UPDATE step_run SET
    status = 'IN_PROGRESS',
    last_worker_id = :workerId,
    attempt_count = attempt_count + 1,
    claimed_at = NOW()
FROM claimed
WHERE step_run.run_id = claimed.run_id
  AND step_run.step_id = claimed.step_id
RETURNING step_run.step_id, step_run.attempt_count;
```

Two application instances racing on the same run both execute this. The
`FOR UPDATE SKIP LOCKED` guarantees one instance's rows are invisible to the
other within a transaction, so neither returns the same step. No application-
level distributed lock is needed, and the semantics map cleanly onto the
in-memory version.

### b) Distributed lock (fallback for storage without SKIP LOCKED)

If the chosen store does not support row-level skip-lock semantics, acquire
a short-lived distributed lock keyed on `runId` via Redis
(`SET lock:run:<id> <token> NX PX 5000`) or ZooKeeper before entering the
claim logic. Release in a `finally`. The service code remains unchanged
beyond acquiring and releasing the lock around the critical section.

Row-level locking is strictly preferred — it does not add a second system
to operate, and avoids the "lock holder died" edge cases distributed locks
require fencing tokens to handle correctly.

---

## 2. Persisting state and recovering after a crash

The repository interfaces in the current code are the seam where this
plugs in. Three stores worth considering:

- **PostgreSQL** — the most straightforward choice. Native support for
  SKIP LOCKED, strong transactional guarantees, decent operational maturity.
- **SQLite** — fine for a single-node deployment or for integration tests
  that want persistence without external dependencies.
- **A write-ahead log (Kafka / append-only table) + materialized view** —
  overkill for this workload, but worth considering if the audit and replay
  requirements grow large (see §3).

**Schema sketch (Postgres):**

```sql
CREATE TABLE workflow_definition (
    workflow_name TEXT PRIMARY KEY,
    definition_json JSONB NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE workflow_run (
    run_id TEXT PRIMARY KEY,
    workflow_name TEXT NOT NULL REFERENCES workflow_definition(workflow_name),
    request_id TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (workflow_name, request_id)   -- enforces idempotency
);

CREATE TABLE step_run (
    run_id TEXT NOT NULL REFERENCES workflow_run(run_id),
    step_id TEXT NOT NULL,
    status TEXT NOT NULL,
    attempt_count INT NOT NULL DEFAULT 0,
    last_worker_id TEXT,
    claimed_at TIMESTAMPTZ,
    lease_expires_at TIMESTAMPTZ,
    PRIMARY KEY (run_id, step_id)
);

CREATE INDEX idx_step_run_runnable ON step_run (run_id, status, priority DESC);
```

**Recovery:** on service start, no action is needed. State is derived from the
tables. Any run with claimed steps whose `lease_expires_at` has passed
becomes reclaimable by any worker (see §4).

**Durability during claim:** the claim transaction is the durability
boundary. Once the `UPDATE` commits, the step is officially claimed and
survives a worker crash. The worker's next heartbeat extends the lease.

---

## 3. Observability, audit history, and replay

### Observability

- **Structured logs** with correlation IDs. Each HTTP request gets a
  trace/span ID (W3C `traceparent`) that propagates through service calls
  and appears on every log line.
- **Metrics via Micrometer / Prometheus:**
  - `workflow.runs.started` (counter, labeled by workflow name)
  - `workflow.steps.claimed` (counter, labeled by workflow + outcome)
  - `workflow.steps.duration` (histogram, from claim to complete)
  - `workflow.runs.active` (gauge)
  - `workflow.steps.blocked_propagations` (counter)
- **Distributed traces via OpenTelemetry.** `claimSteps` and `completeStep`
  become spans so operators can see which worker took which step for which
  run, including latency.

### Audit history and replay

Add an append-only `step_event` table that records every state transition
with timestamp, actor (workerId or `"system"`), and reason. The run summary
becomes a projection; replay is a matter of reading events in order.

```sql
CREATE TABLE step_event (
    event_id BIGSERIAL PRIMARY KEY,
    run_id TEXT NOT NULL,
    step_id TEXT NOT NULL,
    event_type TEXT NOT NULL,         -- CLAIMED, COMPLETED_SUCCESS, COMPLETED_FAIL,
                                      -- BLOCKED, FAILED
    worker_id TEXT,
    attempt_number INT,
    at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    details_json JSONB
);
```

Operations:
- **Full audit** — `SELECT * FROM step_event WHERE run_id = ? ORDER BY event_id`
- **Replay** — read events, replay state transitions, verify final state
  matches `step_run`. Useful both for forensic investigation and for
  validating migrations.

This is a lightweight event sourcing — the authoritative state is still in
`step_run`, but every mutation is also appended to the event log. We get
audit without the operational complexity of pure event sourcing.

---

## 4. Timeouts, stuck steps, and manual retries

### Lease-based claims

Add `lease_expires_at` to `step_run`. When a step is claimed, set
`lease_expires_at = NOW() + lease_duration` (e.g., 60 seconds, or the step's
expected max runtime, configurable per workflow).

Workers heartbeat periodically to extend the lease:
`UPDATE step_run SET lease_expires_at = NOW() + :lease WHERE run_id = ? AND step_id = ? AND last_worker_id = ? AND attempt_count = ?`.

A background reaper (one per cluster, elected via the same locking mechanism
used for claims) runs every N seconds and reclaims expired leases:

```sql
UPDATE step_run SET
    status = 'PENDING',
    last_worker_id = NULL,  -- or keep for audit, add 'orphaned_at' instead
    lease_expires_at = NULL
WHERE status = 'IN_PROGRESS'
  AND lease_expires_at < NOW();
```

A stuck step then re-enters the pool naturally and gets re-claimed on the
next claim call, counting as a new attempt against `maxAttempts`.

### Manual retries

Expose two operational endpoints:

- `POST /runs/{runId}/steps/{stepId}/retry` — resets a step from
  `FAILED` back to `PENDING`. Requires an operator-level credential;
  increments a `manual_retry_count` for audit.
- `POST /runs/{runId}/steps/{stepId}/abort` — forces a step to `FAILED`
  without further attempts, which propagates `BLOCKED` normally.

Both operations append `step_event` rows so the audit trail stays
complete.

### Pause and resume

For long-running workflows an operator may want to pause execution without
losing state. Add a `run.paused` flag; `claimSteps` returns empty while
paused. Resuming simply clears the flag.

---

## 5. Scaling characteristics

The current single-node, in-memory implementation handles roughly:

- Claims and completions bounded by lock contention per run (not between
  runs). Even with hundreds of workers, as long as they work on different
  runs, there is no contention.
- Memory scales linearly with (number of active runs × average steps per run).
  At 10,000 active runs with 20 steps each, roughly 200,000 small objects —
  well within comfortable JVM heap.
- Blocked propagation is O(dependents of the failed step) with a bounded
  queue; cycle detection at registration is O(V + E).

Postgres-backed deployments scale further by moving contention into the
database. The pattern then becomes "many stateless app instances share a
database"; horizontal scaling is cheap. The bottleneck becomes database
write throughput on `step_run`; sharding by `run_id` would allow further
scale if ever needed.

---

## 6. What this design deliberately does **not** do

A few things that would be present in a production system but were out
of scope for the exercise:

- **Authentication and authorization.** Workers would authenticate with a
  rotating credential; operators would carry a stronger scope. Mentioned
  here so it is not forgotten.
- **Rate limiting.** Per-worker and per-run.
- **Workflow definition versioning.** Current implementation does "last
  write wins" on re-registration. A real system would version definitions
  and let a run specify which version it runs against.
- **A UI.** The exercise explicitly says one is not required.
- **A compiled OpenAPI document.** Easy to add via springdoc-openapi; left
  out to keep the dependency footprint small.
