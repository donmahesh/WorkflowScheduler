package com.workflow.scheduler.repository;

import com.workflow.scheduler.domain.WorkflowRun;

import java.util.Optional;

/**
 * Persistence boundary for {@link WorkflowRun}s.
 *
 * <p>Two lookup paths are needed:
 * <ul>
 *   <li>by {@code runId} — the primary identity</li>
 *   <li>by (workflowName, requestId) — supports idempotent start semantics</li>
 * </ul>
 */
public interface WorkflowRunRepository {

    void save(WorkflowRun run);

    Optional<WorkflowRun> findById(String runId);

    Optional<WorkflowRun> findByRequest(String workflowName, String requestId);
}
