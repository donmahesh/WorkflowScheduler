package com.workflow.scheduler.domain;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Immutable template describing the steps and dependencies of a workflow.
 *
 * <p>Once registered, a definition is treated as read-only. A new definition
 * registered with the same {@code workflowName} replaces the previous version
 * (see {@code WorkflowService.registerDefinition}).
 */
public final class WorkflowDefinition {

    private final String workflowName;
    private final List<StepDefinition> steps;
    private final Map<String, StepDefinition> stepsById;

    public WorkflowDefinition(String workflowName, List<StepDefinition> steps) {
        this.workflowName = workflowName;
        // Preserve the caller's original list (duplicates included) so the validator
        // can detect integrity violations. The map is a lookup index only.
        this.steps = List.copyOf(steps);
        // LinkedHashMap preserves insertion order, which helps when logging / debugging.
        Map<String, StepDefinition> indexed = new LinkedHashMap<>();
        for (StepDefinition step : steps) {
            indexed.put(step.getStepId(), step);
        }
        this.stepsById = Collections.unmodifiableMap(indexed);
    }

    public String getWorkflowName() {
        return workflowName;
    }

    public Map<String, StepDefinition> getStepsById() {
        return stepsById;
    }

    public StepDefinition getStep(String stepId) {
        return stepsById.get(stepId);
    }

    public List<StepDefinition> getSteps() {
        return steps;
    }
}
