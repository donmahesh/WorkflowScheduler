package com.workflow.scheduler.domain;

/**
 * Terminal outcome reported by a worker when completing a step attempt.
 */
public enum StepResult {
    SUCCESS,
    FAIL;

    public static StepResult fromString(String value) {
        if (value == null) {
            return null;
        }
        return switch (value.toLowerCase()) {
            case "success" -> SUCCESS;
            case "fail" -> FAIL;
            default -> null;
        };
    }
}
