package com.workflow.scheduler.api.exception;

/**
 * Thrown when an operation is incompatible with the current state of a step or
 * run (HTTP 409).
 *
 * <p>Examples: completing a step that is not currently IN_PROGRESS; wrong
 * worker ID; stale attempt number.
 */
public class InvalidStateException extends RuntimeException {

    public InvalidStateException(String message) {
        super(message);
    }
}
