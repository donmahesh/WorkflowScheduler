package com.workflow.scheduler.service;

import com.workflow.scheduler.api.exception.NotFoundException;
import com.workflow.scheduler.api.exception.ValidationException;
import com.workflow.scheduler.domain.WorkflowDefinition;
import com.workflow.scheduler.domain.WorkflowRun;
import com.workflow.scheduler.repository.WorkflowDefinitionRepository;
import com.workflow.scheduler.repository.WorkflowRunRepository;
import com.workflow.scheduler.service.validation.DefinitionValidator;
import org.springframework.stereotype.Service;

import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Orchestrates workflow definition registration and run creation.
 *
 * <p>Separation of concerns: this service owns identity and idempotency.
 * All step-level state transitions live in {@link SchedulerService}.
 */
@Service
public class WorkflowService {

    private final WorkflowDefinitionRepository definitionRepository;
    private final WorkflowRunRepository runRepository;

    /**
     * Serializes {@link #startRun(String, String)} across threads so the
     * idempotency check-then-create sequence is atomic. A single global lock
     * is acceptable here because run creation is low-frequency compared to
     * claim/complete, and because the critical section is tiny.
     */
    private final ReentrantLock startRunLock = new ReentrantLock();

    public WorkflowService(WorkflowDefinitionRepository definitionRepository,
                           WorkflowRunRepository runRepository) {
        this.definitionRepository = definitionRepository;
        this.runRepository = runRepository;
    }

    /**
     * Validates and stores a workflow definition. If a definition with the same
     * name already exists it is replaced.
     *
     * @throws ValidationException if the definition is structurally or semantically invalid
     */
    public void registerDefinition(WorkflowDefinition definition) {
        DefinitionValidator.validate(definition);
        definitionRepository.save(definition);
    }

    /**
     * Starts a new run for an existing workflow, idempotent by (workflowName, requestId).
     *
     * @throws ValidationException if {@code requestId} is blank
     * @throws NotFoundException   if the workflow is unknown
     */
    public WorkflowRun startRun(String workflowName, String requestId) {
        if (requestId == null || requestId.isBlank()) {
            throw new ValidationException("requestId must not be blank");
        }
        WorkflowDefinition definition = definitionRepository.findByName(workflowName)
                .orElseThrow(() -> new NotFoundException("Unknown workflow: " + workflowName));

        startRunLock.lock();
        try {
            Optional<WorkflowRun> existing = runRepository.findByRequest(workflowName, requestId);
            if (existing.isPresent()) {
                return existing.get();
            }
            WorkflowRun run = new WorkflowRun(generateRunId(), workflowName, requestId, definition);
            runRepository.save(run);
            return run;
        } finally {
            startRunLock.unlock();
        }
    }

    public WorkflowRun getRun(String runId) {
        return runRepository.findById(runId)
                .orElseThrow(() -> new NotFoundException("Unknown runId: " + runId));
    }

    public WorkflowDefinition getDefinition(String workflowName) {
        return definitionRepository.findByName(workflowName)
                .orElseThrow(() -> new NotFoundException("Unknown workflow: " + workflowName));
    }

    private String generateRunId() {
        // UUIDs give us globally unique, collision-free run IDs without coordination.
        // A test-oriented alternative (incrementing counter) could live behind an interface
        // if deterministic IDs are needed for integration tests.
        return "run-" + UUID.randomUUID();
    }
}
