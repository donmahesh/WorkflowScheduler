package com.workflow.scheduler.api;

import com.workflow.scheduler.api.dto.RegisterDefinitionRequest;
import com.workflow.scheduler.domain.WorkflowDefinition;
import com.workflow.scheduler.service.WorkflowService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * HTTP endpoint for registering workflow definitions.
 */
@RestController
@RequestMapping("/workflows")
public class WorkflowController {

    private final WorkflowService workflowService;

    public WorkflowController(WorkflowService workflowService) {
        this.workflowService = workflowService;
    }

    /**
     * {@code POST /workflows}
     * Registers a workflow definition. Re-registering the same name replaces the previous version.
     */
    @PostMapping
    public ResponseEntity<Void> register(@RequestBody RegisterDefinitionRequest request) {
        WorkflowDefinition definition = DtoMapper.toDomain(request);
        workflowService.registerDefinition(definition);
        return ResponseEntity.noContent().build();
    }
}
