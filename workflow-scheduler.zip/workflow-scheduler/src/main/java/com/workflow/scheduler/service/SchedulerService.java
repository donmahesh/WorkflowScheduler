package com.workflow.scheduler.service;

import com.workflow.scheduler.api.exception.InvalidStateException;
import com.workflow.scheduler.api.exception.ValidationException;
import com.workflow.scheduler.domain.RunStatus;
import com.workflow.scheduler.domain.StepDefinition;
import com.workflow.scheduler.domain.StepResult;
import com.workflow.scheduler.domain.StepRun;
import com.workflow.scheduler.domain.StepStatus;
import com.workflow.scheduler.domain.WorkflowDefinition;
import com.workflow.scheduler.domain.WorkflowRun;
import org.springframework.stereotype.Service;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Owns the step-level state machine: claiming runnable steps, completing them,
 * and propagating {@link StepStatus#BLOCKED} transitively when a dependency
 * cannot be satisfied.
 *
 * <h2>Concurrency model</h2>
 * All mutating operations acquire the lock on the specific {@link WorkflowRun}
 * being modified. Concurrent operations on different runs proceed in parallel;
 * concurrent operations on the same run are serialized. This gives us
 * atomicity of multi-step claim selection and avoids contention across runs.
 *
 * <h2>Determinism</h2>
 * When multiple steps are runnable, selection order is deterministic:
 * priority DESC, then stepId ASC. This matters for test reproducibility and
 * for operators reasoning about which worker will get what.
 */
@Service
public class SchedulerService {

    private final WorkflowService workflowService;

    public SchedulerService(WorkflowService workflowService) {
        this.workflowService = workflowService;
    }

    // ----------------------------------------------------------------------
    // Public API
    // ----------------------------------------------------------------------

    /**
     * Claims up to {@code maxCount} runnable steps and marks them IN_PROGRESS.
     *
     * @return list of {@link ClaimedStep} records describing each claim
     * @throws ValidationException   if arguments are invalid
     * @throws InvalidStateException if the run does not exist
     */
    public List<ClaimedStep> claimSteps(String runId, String workerId, int maxCount) {
        if (workerId == null || workerId.isBlank()) {
            throw new ValidationException("workerId must not be blank");
        }

        if (maxCount <= 0) {
            throw new ValidationException("maxCount must be greater than 0");
        }

        WorkflowRun run = workflowService.getRun(runId);
        WorkflowDefinition definition = workflowService.getDefinition(run.getWorkflowName());

        run.getLock().lock();
        try {
            List<StepRun> runnable = findRunnableSteps(run, definition);
            if (runnable.isEmpty()) {
                return List.of();
            }
            List<StepRun> selected = selectByPriority(runnable, definition, maxCount);
            List<ClaimedStep> claims = new ArrayList<>(selected.size());
            for (StepRun step : selected) {
                int attemptNumber = step.claim(workerId);
                claims.add(new ClaimedStep(step.getStepId(), attemptNumber));
            }
            return claims;
        } finally {
            run.getLock().unlock();
        }
    }

    /**
     * Completes a claimed step attempt, updating state and propagating blocked
     * status if the step has exhausted its attempts.
     */
    public void completeStep(String runId, String stepId, String workerId,
                             int attemptNumber, StepResult result) {
        if (workerId == null || workerId.isBlank()) {
            throw new ValidationException("workerId must not be blank");
        }
        if (result == null) {
            throw new ValidationException("result must be either 'success' or 'fail'");
        }
        WorkflowRun run = workflowService.getRun(runId);
        WorkflowDefinition definition = workflowService.getDefinition(run.getWorkflowName());
        StepRun step = run.getStep(stepId);
        if (step == null) {
            throw new ValidationException("Unknown stepId: " + stepId);
        }

        run.getLock().lock();
        try {
            validateCompletion(step, workerId, attemptNumber);
            if (result == StepResult.SUCCESS) {
                step.markSucceeded();
                return;
            }
            // Failure path: check if attempts remain.
            StepDefinition def = definition.getStep(stepId);
            if (step.getAttemptCount() >= def.getMaxAttempts()) {
                step.markFailed();
                propagateBlocked(run, definition, stepId);
            } else {
                step.markRunnableAgain();
            }
        } finally {
            run.getLock().unlock();
        }
    }

    /**
     * Derives the overall {@link RunStatus} from the aggregate step states.
     * Called under the run's lock when generating a summary.
     */
    public RunStatus deriveRunStatus(WorkflowRun run) {
        boolean anyNonTerminal = false;
        boolean anyFailedOrBlocked = false;
        for (StepRun step : run.getStepsById().values()) {
            switch (step.getStatus()) {
                case PENDING, IN_PROGRESS -> anyNonTerminal = true;
                case FAILED, BLOCKED -> anyFailedOrBlocked = true;
                case SUCCEEDED -> { /* no-op */ }
            }
        }
        if (anyNonTerminal) {
            return RunStatus.RUNNING;
        }
        return anyFailedOrBlocked ? RunStatus.FAILED : RunStatus.SUCCEEDED;
    }

    // ----------------------------------------------------------------------
    // Internals — all callers hold the run's lock
    // ----------------------------------------------------------------------

    private void validateCompletion(StepRun step, String workerId, int attemptNumber) {
        if (step.getStatus() != StepStatus.IN_PROGRESS) {
            throw new InvalidStateException(
                    "Step " + step.getStepId() + " is not currently in_progress (status: " + step.getStatus() + ")");
        }
        if (!workerId.equals(step.getLastWorkerId())) {
            throw new InvalidStateException(
                    "Step " + step.getStepId() + " is claimed by a different worker");
        }
        if (attemptNumber != step.getAttemptCount()) {
            throw new InvalidStateException(
                    "Stale attemptNumber for step " + step.getStepId()
                            + ": expected " + step.getAttemptCount() + ", got " + attemptNumber);
        }
    }

    private List<StepRun> findRunnableSteps(WorkflowRun run, WorkflowDefinition definition) {
        List<StepRun> runnable = new ArrayList<>();
        for (StepRun step : run.getStepsById().values()) {
            if (step.getStatus() == StepStatus.PENDING && dependenciesSatisfied(step, run, definition)) {
                runnable.add(step);
            }
        }
        return runnable;
    }

    private boolean dependenciesSatisfied(StepRun step, WorkflowRun run, WorkflowDefinition definition) {
        StepDefinition def = definition.getStep(step.getStepId());
        for (String depId : def.getDependencies()) {
            StepRun dep = run.getStep(depId);
            if (dep == null || dep.getStatus() != StepStatus.SUCCEEDED) {
                return false;
            }
        }
        return true;
    }

    private List<StepRun> selectByPriority(List<StepRun> runnable, WorkflowDefinition definition, int maxCount) {
        // Comparator: higher priority first (DESC), then stepId lexicographically (ASC).
        Comparator<StepRun> comparator = Comparator
                .comparingInt((StepRun s) -> definition.getStep(s.getStepId()).getPriority()).reversed()
                .thenComparing(StepRun::getStepId);
        runnable.sort(comparator);
        return runnable.subList(0, Math.min(maxCount, runnable.size()));
    }

    /**
     * Propagates BLOCKED status forward from a failed step through the
     * reverse-dependency graph. Any step that depends (transitively) on a
     * FAILED or BLOCKED step and is still PENDING becomes BLOCKED.
     *
     * <p>Steps already IN_PROGRESS are left alone; they will be resolved by
     * their own completion. Steps that are terminal are untouched.
     */
    private void propagateBlocked(WorkflowRun run, WorkflowDefinition definition, String failedStepId) {
        Map<String, List<String>> reverseIndex = buildReverseIndex(definition);
        Deque<String> queue = new ArrayDeque<>();
        queue.add(failedStepId);
        while (!queue.isEmpty()) {
            String currentId = queue.poll();
            List<String> dependents = reverseIndex.getOrDefault(currentId, List.of());
            for (String depId : dependents) {
                StepRun depStep = run.getStep(depId);
                if (depStep.getStatus() == StepStatus.PENDING) {
                    depStep.markBlocked();
                    queue.add(depId);
                }
            }
        }
    }

    private Map<String, List<String>> buildReverseIndex(WorkflowDefinition definition) {
        Map<String, List<String>> reverse = new HashMap<>();
        for (StepDefinition step : definition.getSteps()) {
            for (String dep : step.getDependencies()) {
                reverse.computeIfAbsent(dep, k -> new ArrayList<>()).add(step.getStepId());
            }
        }
        return reverse;
    }

    // ----------------------------------------------------------------------
    // Result record returned by claim
    // ----------------------------------------------------------------------

    public record ClaimedStep(String stepId, int attemptNumber) {
    }
}
