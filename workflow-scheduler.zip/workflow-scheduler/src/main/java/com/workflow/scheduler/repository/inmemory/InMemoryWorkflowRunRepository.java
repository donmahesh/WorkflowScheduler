package com.workflow.scheduler.repository.inmemory;

import com.workflow.scheduler.domain.WorkflowRun;
import com.workflow.scheduler.repository.WorkflowRunRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

/**
 * In-memory implementation of {@link WorkflowRunRepository}.
 *
 * <p>Two indices are maintained:
 * <ul>
 *   <li>primary: {@code runId → WorkflowRun}</li>
 *   <li>secondary: {@code (workflowName, requestId) → runId} for idempotent start</li>
 * </ul>
 *
 * <p>The idempotency index key is the composite string
 * {@code workflowName + "::" + requestId}, chosen to avoid clashes between
 * valid names (names are non-blank; "::" is unlikely to appear and the two
 * fields are validated independently anyway).
 */
@Repository
public class InMemoryWorkflowRunRepository implements WorkflowRunRepository {

    private static final String REQUEST_KEY_DELIM = "::";

    private final ConcurrentMap<String, WorkflowRun> runsById = new ConcurrentHashMap<>();
    private final ConcurrentMap<String, String> runIdByRequest = new ConcurrentHashMap<>();

    @Override
    public void save(WorkflowRun run) {
        runsById.put(run.getRunId(), run);
        runIdByRequest.putIfAbsent(requestKey(run.getWorkflowName(), run.getRequestId()), run.getRunId());
    }

    @Override
    public Optional<WorkflowRun> findById(String runId) {
        return Optional.ofNullable(runsById.get(runId));
    }

    @Override
    public Optional<WorkflowRun> findByRequest(String workflowName, String requestId) {
        String runId = runIdByRequest.get(requestKey(workflowName, requestId));
        if (runId == null) {
            return Optional.empty();
        }
        return findById(runId);
    }

    private static String requestKey(String workflowName, String requestId) {
        return workflowName + REQUEST_KEY_DELIM + requestId;
    }
}
