package com.workflow.scheduler.domain;

/**
 * Mutable runtime state for a single step within a {@link WorkflowRun}.
 *
 * <p>Guarded by the owning {@code WorkflowRun}'s lock; callers must hold that
 * lock before invoking any state-changing method.
 */
public final class StepRun {

    private final String stepId;
    private StepStatus status;
    private int attemptCount;
    private String lastWorkerId;

    public StepRun(String stepId) {
        this.stepId = stepId;
        this.status = StepStatus.PENDING;
        this.attemptCount = 0;
        this.lastWorkerId = null;
    }

    public String getStepId() {
        return stepId;
    }

    public StepStatus getStatus() {
        return status;
    }

    public int getAttemptCount() {
        return attemptCount;
    }

    public String getLastWorkerId() {
        return lastWorkerId;
    }

    /**
     * Transitions the step to IN_PROGRESS and records the worker + a new attempt number.
     *
     * @return the attemptNumber assigned to this claim (1-based)
     */
    public int claim(String workerId) {
        this.status = StepStatus.IN_PROGRESS;
        this.attemptCount += 1;
        this.lastWorkerId = workerId;
        return this.attemptCount;
    }

    public void markSucceeded() {
        this.status = StepStatus.SUCCEEDED;
    }

    public void markFailed() {
        this.status = StepStatus.FAILED;
    }

    public void markBlocked() {
        this.status = StepStatus.BLOCKED;
    }

    /**
     * Returns the step to PENDING after a failed attempt where retries remain.
     * The worker and attempt count are preserved so that stale completions can be rejected.
     */
    public void markRunnableAgain() {
        this.status = StepStatus.PENDING;
    }
}
