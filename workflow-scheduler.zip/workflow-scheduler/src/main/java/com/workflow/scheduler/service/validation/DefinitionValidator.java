package com.workflow.scheduler.service.validation;

import com.workflow.scheduler.api.exception.ValidationException;
import com.workflow.scheduler.domain.StepDefinition;
import com.workflow.scheduler.domain.WorkflowDefinition;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Enforces the structural and semantic rules for a {@link WorkflowDefinition}:
 *
 * <ul>
 *   <li>workflowName must be non-blank</li>
 *   <li>at least one step</li>
 *   <li>every stepId non-blank and unique within the workflow</li>
 *   <li>maxAttempts &gt; 0 for every step</li>
 *   <li>every dependency references a known step within the same workflow</li>
 *   <li>no step depends on itself</li>
 *   <li>the dependency graph is acyclic</li>
 * </ul>
 */
public final class DefinitionValidator {

    private DefinitionValidator() {
    }

    public static void validate(WorkflowDefinition definition) {
        if (definition == null) {
            throw new ValidationException("Workflow definition must not be null");
        }
        validateName(definition.getWorkflowName());
        List<StepDefinition> steps = definition.getSteps();
        if (steps.isEmpty()) {
            throw new ValidationException("Workflow definition must contain at least one step");
        }
        Set<String> stepIds = validateStepIdsUnique(steps);
        validateStepFields(steps, stepIds);
        validateCycles(definition);
    }

    private static void validateName(String name) {
        if (name == null || name.isBlank()) {
            throw new ValidationException("workflowName must not be blank");
        }
    }

    private static Set<String> validateStepIdsUnique(List<StepDefinition> steps) {
        Set<String> seen = new HashSet<>();
        for (StepDefinition step : steps) {
            String id = step.getStepId();
            if (id == null || id.isBlank()) {
                throw new ValidationException("stepId must not be blank");
            }
            if (!seen.add(id)) {
                throw new ValidationException("Duplicate stepId: " + id);
            }
        }
        return seen;
    }

    private static void validateStepFields(List<StepDefinition> steps, Set<String> validStepIds) {
        for (StepDefinition step : steps) {
            if (step.getMaxAttempts() <= 0) {
                throw new ValidationException(
                        "maxAttempts must be greater than 0 for step: " + step.getStepId());
            }
            for (String dep : step.getDependencies()) {
                if (dep == null || dep.isBlank()) {
                    throw new ValidationException(
                            "Dependency must not be blank in step: " + step.getStepId());
                }
                if (dep.equals(step.getStepId())) {
                    throw new ValidationException(
                            "Step cannot depend on itself: " + step.getStepId());
                }
                if (!validStepIds.contains(dep)) {
                    throw new ValidationException(
                            "Unknown dependency '" + dep + "' in step: " + step.getStepId());
                }
            }
        }
    }

    private static void validateCycles(WorkflowDefinition definition) {
        List<String> cycle = CycleDetector.findCycle(definition);
        if (!cycle.isEmpty()) {
            throw new ValidationException("Workflow definition contains a cycle: " + cycle);
        }
    }
}
