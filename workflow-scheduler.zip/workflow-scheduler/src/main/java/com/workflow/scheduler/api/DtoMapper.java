package com.workflow.scheduler.api;

import com.workflow.scheduler.api.dto.ClaimedStepDto;
import com.workflow.scheduler.api.dto.RegisterDefinitionRequest;
import com.workflow.scheduler.api.dto.RunSummaryResponse;
import com.workflow.scheduler.api.dto.StepDefinitionDto;
import com.workflow.scheduler.api.dto.StepSummaryDto;
import com.workflow.scheduler.domain.RunStatus;
import com.workflow.scheduler.domain.StepDefinition;
import com.workflow.scheduler.domain.StepRun;
import com.workflow.scheduler.domain.StepStatus;
import com.workflow.scheduler.domain.WorkflowDefinition;
import com.workflow.scheduler.domain.WorkflowRun;
import com.workflow.scheduler.service.SchedulerService;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Translates between HTTP DTOs and domain objects. Centralised here so that
 * domain classes remain free of serialization concerns.
 */
public final class DtoMapper {

    private DtoMapper() {
    }

    public static WorkflowDefinition toDomain(RegisterDefinitionRequest request) {
        List<StepDefinition> steps = new ArrayList<>();
        if (request.getSteps() != null) {
            for (StepDefinitionDto dto : request.getSteps()) {
                steps.add(new StepDefinition(
                        dto.getStepId(),
                        dto.getPriority(),
                        dto.getMaxAttempts(),
                        dto.getDependencies()
                ));
            }
        }
        return new WorkflowDefinition(request.getWorkflowName(), steps);
    }

    public static List<ClaimedStepDto> toClaimedStepDtos(List<SchedulerService.ClaimedStep> claims) {
        List<ClaimedStepDto> result = new ArrayList<>(claims.size());
        for (SchedulerService.ClaimedStep claim : claims) {
            result.add(new ClaimedStepDto(claim.stepId(), claim.attemptNumber()));
        }
        return result;
    }

    public static RunSummaryResponse toRunSummary(WorkflowRun run, RunStatus runStatus) {
        List<StepSummaryDto> steps = new ArrayList<>();
        for (StepRun step : run.getStepsById().values()) {
            steps.add(new StepSummaryDto(
                    step.getStepId(),
                    toApi(step.getStatus()),
                    step.getAttemptCount(),
                    step.getLastWorkerId()
            ));
        }
        // Spec: "Return steps sorted by stepId."
        steps.sort(Comparator.comparing(StepSummaryDto::getStepId));
        return new RunSummaryResponse(
                run.getRunId(),
                run.getWorkflowName(),
                toApi(runStatus),
                steps
        );
    }

    public static String toApi(StepStatus status) {
        return status.name().toLowerCase();
    }

    public static String toApi(RunStatus status) {
        return status.name().toLowerCase();
    }
}
