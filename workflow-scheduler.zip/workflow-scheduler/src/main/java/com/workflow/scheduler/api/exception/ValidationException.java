package com.workflow.scheduler.api.exception;

/**
 * Thrown when input is syntactically or semantically invalid (HTTP 400).
 *
 * <p>Examples: blank name fields, duplicate step IDs, cycles in a workflow
 * definition, invalid {@code maxCount} values.
 */
public class ValidationException extends RuntimeException {

    public ValidationException(String message) {
        super(message);
    }
}
