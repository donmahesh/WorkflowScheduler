package com.workflow.scheduler.api;

import com.workflow.scheduler.api.dto.RunSummaryResponse;
import com.workflow.scheduler.api.dto.StartRunRequest;
import com.workflow.scheduler.api.dto.StartRunResponse;
import com.workflow.scheduler.domain.RunStatus;
import com.workflow.scheduler.domain.WorkflowRun;
import com.workflow.scheduler.service.SchedulerService;
import com.workflow.scheduler.service.WorkflowService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * HTTP endpoints for starting runs and retrieving run summaries.
 */
@RestController
@RequestMapping("/runs")
public class RunController {

    private final WorkflowService workflowService;
    private final SchedulerService schedulerService;

    public RunController(WorkflowService workflowService, SchedulerService schedulerService) {
        this.workflowService = workflowService;
        this.schedulerService = schedulerService;
    }

    /**
     * {@code POST /runs} — starts a workflow run.
     * Idempotent by (workflowName, requestId).
     */
    @PostMapping
    public ResponseEntity<StartRunResponse> start(@RequestBody StartRunRequest request) {
        WorkflowRun run = workflowService.startRun(request.getWorkflowName(), request.getRequestId());
        RunStatus status;
        run.getLock().lock();
        try {
            status = schedulerService.deriveRunStatus(run);
        } finally {
            run.getLock().unlock();
        }
        return ResponseEntity.ok(new StartRunResponse(
                run.getRunId(),
                run.getWorkflowName(),
                DtoMapper.toApi(status)
        ));
    }

    /**
     * {@code GET /runs/{runId}} — returns a point-in-time summary of a run.
     */
    @GetMapping("/{runId}")
    public ResponseEntity<RunSummaryResponse> getSummary(@PathVariable String runId) {
        WorkflowRun run = workflowService.getRun(runId);
        RunStatus status;
        run.getLock().lock();
        try {
            status = schedulerService.deriveRunStatus(run);
            return ResponseEntity.ok(DtoMapper.toRunSummary(run, status));
        } finally {
            run.getLock().unlock();
        }
    }
}
