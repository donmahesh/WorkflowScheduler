package com.workflow.scheduler.domain;

/**
 * Lifecycle states for a step within a workflow run.
 *
 * <p>Transitions (enforced by {@code SchedulerService}):
 * <ul>
 *   <li>{@link #PENDING} → {@link #IN_PROGRESS}: via claim</li>
 *   <li>{@link #IN_PROGRESS} → {@link #SUCCEEDED}: via complete(success)</li>
 *   <li>{@link #IN_PROGRESS} → {@link #PENDING}: via complete(fail) when attempts remain</li>
 *   <li>{@link #IN_PROGRESS} → {@link #FAILED}: via complete(fail) when no attempts remain</li>
 *   <li>{@link #PENDING} → {@link #BLOCKED}: when a dependency transitions to FAILED or BLOCKED</li>
 * </ul>
 *
 * <p>{@link #SUCCEEDED}, {@link #FAILED}, and {@link #BLOCKED} are terminal.
 */
public enum StepStatus {
    PENDING,
    IN_PROGRESS,
    SUCCEEDED,
    FAILED,
    BLOCKED;

    public boolean isTerminal() {
        return this == SUCCEEDED || this == FAILED || this == BLOCKED;
    }

    public boolean isUnrecoverable() {
        return this == FAILED || this == BLOCKED;
    }
}
