package com.workflow.scheduler.domain;

import java.util.List;
import java.util.Objects;

/**
 * Immutable description of a single step within a workflow definition.
 *
 * <p>Instances are validated by {@code DefinitionValidator} prior to being stored.
 */
public final class StepDefinition {

    private final String stepId;
    private final int priority;
    private final int maxAttempts;
    private final List<String> dependencies;

    public StepDefinition(String stepId, int priority, int maxAttempts, List<String> dependencies) {
        this.stepId = stepId;
        this.priority = priority;
        this.maxAttempts = maxAttempts;
        this.dependencies = dependencies == null ? List.of() : List.copyOf(dependencies);
    }

    public String getStepId() {
        return stepId;
    }

    public int getPriority() {
        return priority;
    }

    public int getMaxAttempts() {
        return maxAttempts;
    }

    public List<String> getDependencies() {
        return dependencies;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof StepDefinition that)) return false;
        return priority == that.priority
                && maxAttempts == that.maxAttempts
                && Objects.equals(stepId, that.stepId)
                && Objects.equals(dependencies, that.dependencies);
    }

    @Override
    public int hashCode() {
        return Objects.hash(stepId, priority, maxAttempts, dependencies);
    }
}
