package com.workflow.scheduler.api.exception;

/**
 * Thrown when a referenced workflow name or run ID does not exist (HTTP 404).
 */
public class NotFoundException extends RuntimeException {

    public NotFoundException(String message) {
        super(message);
    }
}
