package com.workflow.scheduler.domain;

/**
 * Overall status of a workflow run, derived from the aggregate state of its steps.
 *
 * <p>Rules:
 * <ul>
 *   <li>{@link #RUNNING}: at least one step is PENDING or IN_PROGRESS</li>
 *   <li>{@link #SUCCEEDED}: every step is SUCCEEDED</li>
 *   <li>{@link #FAILED}: all steps terminal AND at least one is FAILED or BLOCKED</li>
 * </ul>
 */
public enum RunStatus {
    RUNNING,
    SUCCEEDED,
    FAILED
}
