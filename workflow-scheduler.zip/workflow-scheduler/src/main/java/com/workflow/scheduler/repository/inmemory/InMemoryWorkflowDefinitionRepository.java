package com.workflow.scheduler.repository.inmemory;

import com.workflow.scheduler.domain.WorkflowDefinition;
import com.workflow.scheduler.repository.WorkflowDefinitionRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

/**
 * In-memory implementation of {@link WorkflowDefinitionRepository}.
 *
 * <p>Thread-safe via {@link ConcurrentHashMap}. State is lost on process
 * restart; for a production deployment this would be replaced with a
 * database-backed implementation (see README).
 */
@Repository
public class InMemoryWorkflowDefinitionRepository implements WorkflowDefinitionRepository {

    private final ConcurrentMap<String, WorkflowDefinition> definitionsByName = new ConcurrentHashMap<>();

    @Override
    public void save(WorkflowDefinition definition) {
        definitionsByName.put(definition.getWorkflowName(), definition);
    }

    @Override
    public Optional<WorkflowDefinition> findByName(String workflowName) {
        return Optional.ofNullable(definitionsByName.get(workflowName));
    }
}
