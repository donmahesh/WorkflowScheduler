package com.workflow.scheduler.api.dto;

import java.util.List;

public class RegisterDefinitionRequest {

    private String workflowName;
    private List<StepDefinitionDto> steps;

    public RegisterDefinitionRequest() {
    }

    public String getWorkflowName() {
        return workflowName;
    }

    public void setWorkflowName(String workflowName) {
        this.workflowName = workflowName;
    }

    public List<StepDefinitionDto> getSteps() {
        return steps;
    }

    public void setSteps(List<StepDefinitionDto> steps) {
        this.steps = steps;
    }
}
