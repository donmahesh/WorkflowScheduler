package com.workflow.scheduler.service.validation;

import com.workflow.scheduler.domain.StepDefinition;
import com.workflow.scheduler.domain.WorkflowDefinition;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Detects cycles in a workflow definition's dependency graph via DFS with
 * three-color marking (white / gray / black).
 *
 * <p>A gray-visited vertex encountered during traversal indicates a back edge
 * and therefore a cycle. The detector returns the first cycle discovered,
 * expressed as the ordered list of step IDs forming it.
 */
public final class CycleDetector {

    private enum Color {
        WHITE, GRAY, BLACK
    }

    private CycleDetector() {
    }

    /**
     * @return the list of stepIds forming a cycle, or empty if the graph is acyclic
     */
    public static List<String> findCycle(WorkflowDefinition definition) {
        Map<String, Color> colors = new HashMap<>();
        for (String stepId : definition.getStepsById().keySet()) {
            colors.put(stepId, Color.WHITE);
        }
        List<String> currentPath = new ArrayList<>();
        for (String stepId : definition.getStepsById().keySet()) {
            if (colors.get(stepId) == Color.WHITE) {
                List<String> cycle = dfs(stepId, definition, colors, currentPath);
                if (!cycle.isEmpty()) {
                    return cycle;
                }
            }
        }
        return List.of();
    }

    private static List<String> dfs(String stepId, WorkflowDefinition definition,
                                    Map<String, Color> colors, List<String> currentPath) {
        colors.put(stepId, Color.GRAY);
        currentPath.add(stepId);
        StepDefinition step = definition.getStep(stepId);
        if (step != null) {
            for (String dep : step.getDependencies()) {
                Color depColor = colors.get(dep);
                if (depColor == Color.GRAY) {
                    // Back edge: extract the cycle from currentPath starting at dep
                    int cycleStart = currentPath.indexOf(dep);
                    List<String> cycle = new ArrayList<>(currentPath.subList(cycleStart, currentPath.size()));
                    cycle.add(dep); // close the loop for readability
                    return cycle;
                }
                if (depColor == Color.WHITE) {
                    List<String> cycle = dfs(dep, definition, colors, currentPath);
                    if (!cycle.isEmpty()) {
                        return cycle;
                    }
                }
            }
        }
        colors.put(stepId, Color.BLACK);
        currentPath.remove(currentPath.size() - 1);
        return List.of();
    }
}
