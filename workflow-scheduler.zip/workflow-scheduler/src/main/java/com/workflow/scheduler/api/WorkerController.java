package com.workflow.scheduler.api;

import com.workflow.scheduler.api.dto.ClaimStepsRequest;
import com.workflow.scheduler.api.dto.ClaimedStepDto;
import com.workflow.scheduler.api.dto.CompleteStepRequest;
import com.workflow.scheduler.api.exception.ValidationException;
import com.workflow.scheduler.domain.StepResult;
import com.workflow.scheduler.service.SchedulerService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * HTTP endpoints for the worker side of the API: claim steps and report
 * completion.
 */
@RestController
@RequestMapping("/workers")
public class WorkerController {

    private final SchedulerService schedulerService;

    public WorkerController(SchedulerService schedulerService) {
        this.schedulerService = schedulerService;
    }

    /**
     * {@code POST /workers/claim}
     * Returns up to {@code maxCount} runnable steps and marks each IN_PROGRESS.
     */
    @PostMapping("/claim")
    public ResponseEntity<List<ClaimedStepDto>> claim(@RequestBody ClaimStepsRequest request) {
        List<SchedulerService.ClaimedStep> claims = schedulerService.claimSteps(
                request.getRunId(), request.getWorkerId(), request.getMaxCount());
        return ResponseEntity.ok(DtoMapper.toClaimedStepDtos(claims));
    }

    /**
     * {@code POST /workers/complete}
     * Marks the step attempt as succeeded or failed.
     */
    @PostMapping("/complete")
    public ResponseEntity<Void> complete(@RequestBody CompleteStepRequest request) {
        StepResult result = StepResult.fromString(request.getResult());
        if (result == null) {
            throw new ValidationException("result must be either 'success' or 'fail'");
        }
        schedulerService.completeStep(
                request.getRunId(),
                request.getStepId(),
                request.getWorkerId(),
                request.getAttemptNumber(),
                result
        );
        return ResponseEntity.noContent().build();
    }
}
