package com.workflow.scheduler.api.dto;

public class StartRunRequest {

    private String workflowName;
    private String requestId;

    public StartRunRequest() {
    }

    public String getWorkflowName() {
        return workflowName;
    }

    public void setWorkflowName(String workflowName) {
        this.workflowName = workflowName;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }
}
