package com.workflow.scheduler;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Entry point for the Persistent Workflow Scheduler service.
 */
@SpringBootApplication
public class WorkflowSchedulerApplication {

    public static void main(String[] args) {
        SpringApplication.run(WorkflowSchedulerApplication.class, args);
    }

}
