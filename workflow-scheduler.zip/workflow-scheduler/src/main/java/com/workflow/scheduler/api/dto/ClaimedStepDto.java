package com.workflow.scheduler.api.dto;

public class ClaimedStepDto {

    private final String stepId;
    private final int attemptNumber;

    public ClaimedStepDto(String stepId, int attemptNumber) {
        this.stepId = stepId;
        this.attemptNumber = attemptNumber;
    }

    public String getStepId() {
        return stepId;
    }

    public int getAttemptNumber() {
        return attemptNumber;
    }
}
