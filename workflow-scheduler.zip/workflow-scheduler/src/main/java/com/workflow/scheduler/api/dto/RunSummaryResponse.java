package com.workflow.scheduler.api.dto;

import java.util.List;

public class RunSummaryResponse {

    private final String runId;
    private final String workflowName;
    private final String runStatus;
    private final List<StepSummaryDto> steps;

    public RunSummaryResponse(String runId, String workflowName, String runStatus,
                              List<StepSummaryDto> steps) {
        this.runId = runId;
        this.workflowName = workflowName;
        this.runStatus = runStatus;
        this.steps = steps;
    }

    public String getRunId() {
        return runId;
    }

    public String getWorkflowName() {
        return workflowName;
    }

    public String getRunStatus() {
        return runStatus;
    }

    public List<StepSummaryDto> getSteps() {
        return steps;
    }
}
