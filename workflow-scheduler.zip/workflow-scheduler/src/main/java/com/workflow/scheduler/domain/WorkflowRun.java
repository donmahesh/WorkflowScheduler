package com.workflow.scheduler.domain;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.locks.ReentrantLock;

/**
 * A single execution instance of a {@link WorkflowDefinition}.
 *
 * <p>Thread-safety: all state transitions on a run are serialized through
 * {@link #getLock()}. Callers (the service layer) are responsible for acquiring
 * and releasing the lock around any claim/complete operation. Per-run locking
 * keeps the hot path narrow — concurrent runs do not contend with each other.
 */
public final class WorkflowRun {

    private final String runId;
    private final String workflowName;
    private final String requestId;
    private final Map<String, StepRun> stepsById;
    private final ReentrantLock lock = new ReentrantLock();

    public WorkflowRun(String runId, String workflowName, String requestId,
                       WorkflowDefinition definition) {
        this.runId = runId;
        this.workflowName = workflowName;
        this.requestId = requestId;
        Map<String, StepRun> steps = new LinkedHashMap<>();
        for (StepDefinition stepDef : definition.getSteps()) {
            steps.put(stepDef.getStepId(), new StepRun(stepDef.getStepId()));
        }
        this.stepsById = steps;
    }

    public String getRunId() {
        return runId;
    }

    public String getWorkflowName() {
        return workflowName;
    }

    public String getRequestId() {
        return requestId;
    }

    public Map<String, StepRun> getStepsById() {
        return stepsById;
    }

    public StepRun getStep(String stepId) {
        return stepsById.get(stepId);
    }

    public ReentrantLock getLock() {
        return lock;
    }
}
