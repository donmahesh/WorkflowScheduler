package com.workflow.scheduler.repository;

import com.workflow.scheduler.domain.WorkflowDefinition;

import java.util.Optional;

/**
 * Persistence boundary for {@link WorkflowDefinition}s. Keeping this as an
 * interface isolates the domain and service layers from any specific storage
 * technology so an alternative implementation (JDBC, Spring Data JPA, etc.)
 * can be swapped in without changes elsewhere.
 */
public interface WorkflowDefinitionRepository {

    void save(WorkflowDefinition definition);

    Optional<WorkflowDefinition> findByName(String workflowName);
}
