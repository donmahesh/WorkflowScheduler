package com.workflow.scheduler.api.dto;

public class StepSummaryDto {

    private final String stepId;
    private final String status;
    private final int attemptCount;
    private final String lastWorkerId;

    public StepSummaryDto(String stepId, String status, int attemptCount, String lastWorkerId) {
        this.stepId = stepId;
        this.status = status;
        this.attemptCount = attemptCount;
        this.lastWorkerId = lastWorkerId;
    }

    public String getStepId() {
        return stepId;
    }

    public String getStatus() {
        return status;
    }

    public int getAttemptCount() {
        return attemptCount;
    }

    public String getLastWorkerId() {
        return lastWorkerId;
    }
}
