package com.workflow.scheduler.api.dto;

public class StartRunResponse {

    private final String runId;
    private final String workflowName;
    private final String runStatus;

    public StartRunResponse(String runId, String workflowName, String runStatus) {
        this.runId = runId;
        this.workflowName = workflowName;
        this.runStatus = runStatus;
    }

    public String getRunId() {
        return runId;
    }

    public String getWorkflowName() {
        return workflowName;
    }

    public String getRunStatus() {
        return runStatus;
    }
}
