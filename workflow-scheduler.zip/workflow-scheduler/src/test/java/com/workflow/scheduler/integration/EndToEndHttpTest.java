package com.workflow.scheduler.integration;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Integration test exercising the HTTP API end-to-end.
 *
 * <p>Uses Spring's MockMvc rather than hitting a live port, so the test runs
 * fast and remains hermetic. The full stack (controllers, services, in-memory
 * repositories, exception handler) is wired up.
 */
@SpringBootTest
@AutoConfigureMockMvc
class EndToEndHttpTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void fullHappyPathScenario() throws Exception {
        // Register the model-publish workflow from the exercise doc.
        String registerBody = """
            {
              "workflowName": "model-publish",
              "steps": [
                { "stepId": "load-model", "priority": 10, "maxAttempts": 1, "dependencies": [] },
                { "stepId": "validate-schema", "priority": 9, "maxAttempts": 2, "dependencies": ["load-model"] },
                { "stepId": "write-audit", "priority": 5, "maxAttempts": 1, "dependencies": ["load-model"] },
                { "stepId": "persist-metadata", "priority": 8, "maxAttempts": 1, "dependencies": ["validate-schema"] },
                { "stepId": "publish-event", "priority": 7, "maxAttempts": 1, "dependencies": ["persist-metadata", "write-audit"] }
              ]
            }
            """;
        mockMvc.perform(post("/workflows").contentType(MediaType.APPLICATION_JSON).content(registerBody))
                .andExpect(status().isNoContent());

        // Start a run.
        String startBody = """
            { "workflowName": "model-publish", "requestId": "req-1001" }
            """;
        MvcResult startResult = mockMvc.perform(post("/runs").contentType(MediaType.APPLICATION_JSON).content(startBody))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.workflowName").value("model-publish"))
                .andExpect(jsonPath("$.runStatus").value("running"))
                .andReturn();
        String runId = objectMapper.readTree(startResult.getResponse().getContentAsString()).get("runId").asText();

        // Idempotent start - same requestId yields the same runId.
        MvcResult secondStart = mockMvc.perform(post("/runs").contentType(MediaType.APPLICATION_JSON).content(startBody))
                .andExpect(status().isOk())
                .andReturn();
        String secondRunId = objectMapper.readTree(secondStart.getResponse().getContentAsString()).get("runId").asText();
        assertThat(secondRunId).isEqualTo(runId);

        // Claim: only load-model is runnable.
        String claimBody = String.format("""
            { "runId": "%s", "workerId": "worker-a", "maxCount": 2 }
            """, runId);
        MvcResult claim1 = mockMvc.perform(post("/workers/claim").contentType(MediaType.APPLICATION_JSON).content(claimBody))
                .andExpect(status().isOk())
                .andReturn();
        JsonNode claims1 = objectMapper.readTree(claim1.getResponse().getContentAsString());
        assertThat(claims1).hasSize(1);
        assertThat(claims1.get(0).get("stepId").asText()).isEqualTo("load-model");
        assertThat(claims1.get(0).get("attemptNumber").asInt()).isEqualTo(1);

        // Complete load-model successfully.
        String completeBody = String.format("""
            { "runId": "%s", "stepId": "load-model", "workerId": "worker-a", "attemptNumber": 1, "result": "success" }
            """, runId);
        mockMvc.perform(post("/workers/complete").contentType(MediaType.APPLICATION_JSON).content(completeBody))
                .andExpect(status().isNoContent());

        // Second claim: validate-schema and write-audit become runnable.
        MvcResult claim2 = mockMvc.perform(post("/workers/claim").contentType(MediaType.APPLICATION_JSON).content(claimBody))
                .andExpect(status().isOk())
                .andReturn();
        JsonNode claims2 = objectMapper.readTree(claim2.getResponse().getContentAsString());
        assertThat(claims2).hasSize(2);
        assertThat(claims2.get(0).get("stepId").asText()).isEqualTo("validate-schema");
        assertThat(claims2.get(1).get("stepId").asText()).isEqualTo("write-audit");

        // Summary endpoint.
        mockMvc.perform(get("/runs/" + runId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.runStatus").value("running"))
                .andExpect(jsonPath("$.steps[0].stepId").value("load-model"))
                .andExpect(jsonPath("$.steps[0].status").value("succeeded"));
    }

    @Test
    void invalidDefinitionReturns400() throws Exception {
        String body = """
            {
              "workflowName": "cyclic",
              "steps": [
                { "stepId": "a", "priority": 1, "maxAttempts": 1, "dependencies": ["b"] },
                { "stepId": "b", "priority": 1, "maxAttempts": 1, "dependencies": ["a"] }
              ]
            }
            """;
        mockMvc.perform(post("/workflows").contentType(MediaType.APPLICATION_JSON).content(body))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.error").value("validation_error"));
    }

    @Test
    void unknownRunReturns404() throws Exception {
        mockMvc.perform(get("/runs/missing"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.error").value("not_found"));
    }
}
