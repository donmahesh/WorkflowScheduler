package com.workflow.scheduler.service.validation;

import com.workflow.scheduler.api.exception.ValidationException;
import com.workflow.scheduler.domain.StepDefinition;
import com.workflow.scheduler.domain.WorkflowDefinition;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThatCode;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class DefinitionValidatorTest {

    @Test
    void validDefinitionPasses() {
        WorkflowDefinition def = new WorkflowDefinition("w", List.of(
                new StepDefinition("a", 1, 1, List.of()),
                new StepDefinition("b", 1, 2, List.of("a"))
        ));
        assertThatCode(() -> DefinitionValidator.validate(def)).doesNotThrowAnyException();
    }

    @Test
    void blankWorkflowNameRejected() {
        WorkflowDefinition def = new WorkflowDefinition("  ",
                List.of(new StepDefinition("a", 1, 1, List.of())));
        assertThatThrownBy(() -> DefinitionValidator.validate(def))
                .isInstanceOf(ValidationException.class)
                .hasMessageContaining("workflowName");
    }

    @Test
    void nullWorkflowNameRejected() {
        WorkflowDefinition def = new WorkflowDefinition(null,
                List.of(new StepDefinition("a", 1, 1, List.of())));
        assertThatThrownBy(() -> DefinitionValidator.validate(def))
                .isInstanceOf(ValidationException.class);
    }

    @Test
    void emptyStepsRejected() {
        WorkflowDefinition def = new WorkflowDefinition("w", List.of());
        assertThatThrownBy(() -> DefinitionValidator.validate(def))
                .isInstanceOf(ValidationException.class)
                .hasMessageContaining("at least one step");
    }

    @Test
    void duplicateStepIdRejected() {
        WorkflowDefinition def = new WorkflowDefinition("w", List.of(
                new StepDefinition("a", 1, 1, List.of()),
                new StepDefinition("a", 1, 1, List.of())
        ));
        assertThatThrownBy(() -> DefinitionValidator.validate(def))
                .isInstanceOf(ValidationException.class)
                .hasMessageContaining("Duplicate");
    }

    @Test
    void blankStepIdRejected() {
        WorkflowDefinition def = new WorkflowDefinition("w", List.of(
                new StepDefinition("  ", 1, 1, List.of())
        ));
        assertThatThrownBy(() -> DefinitionValidator.validate(def))
                .isInstanceOf(ValidationException.class)
                .hasMessageContaining("stepId");
    }

    @Test
    void zeroMaxAttemptsRejected() {
        WorkflowDefinition def = new WorkflowDefinition("w", List.of(
                new StepDefinition("a", 1, 0, List.of())
        ));
        assertThatThrownBy(() -> DefinitionValidator.validate(def))
                .isInstanceOf(ValidationException.class)
                .hasMessageContaining("maxAttempts");
    }

    @Test
    void negativeMaxAttemptsRejected() {
        WorkflowDefinition def = new WorkflowDefinition("w", List.of(
                new StepDefinition("a", 1, -1, List.of())
        ));
        assertThatThrownBy(() -> DefinitionValidator.validate(def))
                .isInstanceOf(ValidationException.class);
    }

    @Test
    void unknownDependencyRejected() {
        WorkflowDefinition def = new WorkflowDefinition("w", List.of(
                new StepDefinition("a", 1, 1, List.of("ghost"))
        ));
        assertThatThrownBy(() -> DefinitionValidator.validate(def))
                .isInstanceOf(ValidationException.class)
                .hasMessageContaining("Unknown dependency");
    }

    @Test
    void selfDependencyRejected() {
        WorkflowDefinition def = new WorkflowDefinition("w", List.of(
                new StepDefinition("a", 1, 1, List.of("a"))
        ));
        assertThatThrownBy(() -> DefinitionValidator.validate(def))
                .isInstanceOf(ValidationException.class)
                .hasMessageContaining("depend on itself");
    }

    @Test
    void cycleRejected() {
        WorkflowDefinition def = new WorkflowDefinition("w", List.of(
                new StepDefinition("a", 1, 1, List.of("b")),
                new StepDefinition("b", 1, 1, List.of("a"))
        ));
        assertThatThrownBy(() -> DefinitionValidator.validate(def))
                .isInstanceOf(ValidationException.class)
                .hasMessageContaining("cycle");
    }
}
