package com.workflow.scheduler.service;

import com.workflow.scheduler.api.exception.NotFoundException;
import com.workflow.scheduler.api.exception.ValidationException;
import com.workflow.scheduler.domain.StepDefinition;
import com.workflow.scheduler.domain.WorkflowDefinition;
import com.workflow.scheduler.domain.WorkflowRun;
import com.workflow.scheduler.repository.inmemory.InMemoryWorkflowDefinitionRepository;
import com.workflow.scheduler.repository.inmemory.InMemoryWorkflowRunRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class WorkflowServiceTest {

    private WorkflowService workflowService;

    @BeforeEach
    void setUp() {
        workflowService = new WorkflowService(
                new InMemoryWorkflowDefinitionRepository(),
                new InMemoryWorkflowRunRepository()
        );
    }

    @Test
    void registerThenStartRunSucceeds() {
        workflowService.registerDefinition(simpleDefinition());
        WorkflowRun run = workflowService.startRun("w", "req-1");
        assertThat(run.getRunId()).startsWith("run-");
        assertThat(run.getWorkflowName()).isEqualTo("w");
        assertThat(run.getRequestId()).isEqualTo("req-1");
        assertThat(run.getStepsById()).containsOnlyKeys("a", "b");
    }

    @Test
    void startRunIsIdempotentBySameRequestId() {
        workflowService.registerDefinition(simpleDefinition());
        WorkflowRun first = workflowService.startRun("w", "req-1");
        WorkflowRun second = workflowService.startRun("w", "req-1");
        assertThat(second.getRunId()).isEqualTo(first.getRunId());
    }

    @Test
    void sameRequestIdOnDifferentWorkflowProducesSeparateRun() {
        workflowService.registerDefinition(simpleDefinition());
        workflowService.registerDefinition(simpleDefinitionNamed("other"));
        WorkflowRun r1 = workflowService.startRun("w", "req-1");
        WorkflowRun r2 = workflowService.startRun("other", "req-1");
        assertThat(r2.getRunId()).isNotEqualTo(r1.getRunId());
    }

    @Test
    void startRunOnUnknownWorkflowThrows() {
        assertThatThrownBy(() -> workflowService.startRun("missing", "req-1"))
                .isInstanceOf(NotFoundException.class);
    }

    @Test
    void startRunWithBlankRequestIdThrows() {
        workflowService.registerDefinition(simpleDefinition());
        assertThatThrownBy(() -> workflowService.startRun("w", "  "))
                .isInstanceOf(ValidationException.class);
    }

    @Test
    void getRunOnUnknownIdThrows() {
        assertThatThrownBy(() -> workflowService.getRun("nope"))
                .isInstanceOf(NotFoundException.class);
    }

    private WorkflowDefinition simpleDefinition() {
        return simpleDefinitionNamed("w");
    }

    private WorkflowDefinition simpleDefinitionNamed(String name) {
        return new WorkflowDefinition(name, List.of(
                new StepDefinition("a", 1, 1, List.of()),
                new StepDefinition("b", 1, 1, List.of("a"))
        ));
    }
}
