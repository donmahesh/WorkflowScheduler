package com.workflow.scheduler.service.validation;

import com.workflow.scheduler.domain.StepDefinition;
import com.workflow.scheduler.domain.WorkflowDefinition;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class CycleDetectorTest {

    @Test
    void acyclicGraphReturnsEmpty() {
        WorkflowDefinition def = new WorkflowDefinition("w", List.of(
                step("a", List.of()),
                step("b", List.of("a")),
                step("c", List.of("a")),
                step("d", List.of("b", "c"))
        ));
        assertThat(CycleDetector.findCycle(def)).isEmpty();
    }

    @Test
    void simpleTwoNodeCycleDetected() {
        WorkflowDefinition def = new WorkflowDefinition("w", List.of(
                step("a", List.of("b")),
                step("b", List.of("a"))
        ));
        assertThat(CycleDetector.findCycle(def)).isNotEmpty();
    }

    @Test
    void threeNodeCycleDetected() {
        WorkflowDefinition def = new WorkflowDefinition("w", List.of(
                step("a", List.of("c")),
                step("b", List.of("a")),
                step("c", List.of("b"))
        ));
        assertThat(CycleDetector.findCycle(def)).isNotEmpty();
    }

    @Test
    void cycleHiddenBehindAcyclicPrefixIsDetected() {
        WorkflowDefinition def = new WorkflowDefinition("w", List.of(
                step("root", List.of()),
                step("a", List.of("root", "c")),
                step("b", List.of("a")),
                step("c", List.of("b"))
        ));
        assertThat(CycleDetector.findCycle(def)).isNotEmpty();
    }

    @Test
    void diamondDependencyIsAcyclic() {
        WorkflowDefinition def = new WorkflowDefinition("w", List.of(
                step("a", List.of()),
                step("b", List.of("a")),
                step("c", List.of("a")),
                step("d", List.of("b", "c"))
        ));
        assertThat(CycleDetector.findCycle(def)).isEmpty();
    }

    private static StepDefinition step(String id, List<String> deps) {
        return new StepDefinition(id, 1, 1, deps);
    }
}
