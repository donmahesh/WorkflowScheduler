package com.workflow.scheduler.service;

import com.workflow.scheduler.api.exception.InvalidStateException;
import com.workflow.scheduler.api.exception.ValidationException;
import com.workflow.scheduler.domain.RunStatus;
import com.workflow.scheduler.domain.StepDefinition;
import com.workflow.scheduler.domain.StepResult;
import com.workflow.scheduler.domain.StepStatus;
import com.workflow.scheduler.domain.WorkflowDefinition;
import com.workflow.scheduler.domain.WorkflowRun;
import com.workflow.scheduler.repository.inmemory.InMemoryWorkflowDefinitionRepository;
import com.workflow.scheduler.repository.inmemory.InMemoryWorkflowRunRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class SchedulerServiceTest {

    private WorkflowService workflowService;
    private SchedulerService schedulerService;

    @BeforeEach
    void setUp() {
        workflowService = new WorkflowService(
                new InMemoryWorkflowDefinitionRepository(),
                new InMemoryWorkflowRunRepository()
        );
        schedulerService = new SchedulerService(workflowService);
    }

    // ----------------------------------------------------------------------
    // Example from exercise doc, end-to-end
    // ----------------------------------------------------------------------

    @Test
    void exampleScenarioMatchesDocumentation() {
        workflowService.registerDefinition(modelPublishDefinition());
        WorkflowRun run = workflowService.startRun("model-publish", "req-1001");

        // Only load-model is runnable initially (everything else depends on it).
        List<SchedulerService.ClaimedStep> claims = schedulerService.claimSteps(run.getRunId(), "worker-a", 2);
        assertThat(claims).extracting(SchedulerService.ClaimedStep::stepId).containsExactly("load-model");
        assertThat(claims.get(0).attemptNumber()).isEqualTo(1);

        schedulerService.completeStep(run.getRunId(), "load-model", "worker-a", 1, StepResult.SUCCESS);

        // Now validate-schema (priority 9) and write-audit (priority 5) are runnable.
        // Higher priority first → validate-schema; then write-audit.
        claims = schedulerService.claimSteps(run.getRunId(), "worker-a", 2);
        assertThat(claims).extracting(SchedulerService.ClaimedStep::stepId)
                .containsExactly("validate-schema", "write-audit");

        // Complete one success and one failure.
        schedulerService.completeStep(run.getRunId(), "write-audit", "worker-a", 1, StepResult.SUCCESS);
        schedulerService.completeStep(run.getRunId(), "validate-schema", "worker-a", 1, StepResult.FAIL);

        // validate-schema has maxAttempts=2, so it is runnable again (attempt 2).
        claims = schedulerService.claimSteps(run.getRunId(), "worker-b", 2);
        assertThat(claims).extracting(SchedulerService.ClaimedStep::stepId).containsExactly("validate-schema");
        assertThat(claims.get(0).attemptNumber()).isEqualTo(2);
    }

    // ----------------------------------------------------------------------
    // Claim ordering
    // ----------------------------------------------------------------------

    @Test
    void claimRespectsPriorityDescendingThenStepIdAscending() {
        workflowService.registerDefinition(new WorkflowDefinition("w", List.of(
                new StepDefinition("c-low-id", 1, 1, List.of()),
                new StepDefinition("a-same-priority", 5, 1, List.of()),
                new StepDefinition("b-same-priority", 5, 1, List.of()),
                new StepDefinition("z-high-priority", 10, 1, List.of())
        )));
        WorkflowRun run = workflowService.startRun("w", "r");
        List<SchedulerService.ClaimedStep> claims = schedulerService.claimSteps(run.getRunId(), "w1", 10);

        assertThat(claims).extracting(SchedulerService.ClaimedStep::stepId)
                .containsExactly("z-high-priority", "a-same-priority", "b-same-priority", "c-low-id");
    }

    @Test
    void claimReturnsAtMostMaxCount() {
        workflowService.registerDefinition(new WorkflowDefinition("w", List.of(
                new StepDefinition("a", 1, 1, List.of()),
                new StepDefinition("b", 1, 1, List.of()),
                new StepDefinition("c", 1, 1, List.of())
        )));
        WorkflowRun run = workflowService.startRun("w", "r");
        List<SchedulerService.ClaimedStep> claims = schedulerService.claimSteps(run.getRunId(), "w1", 2);
        assertThat(claims).hasSize(2);
    }

    @Test
    void claimReturnsEmptyWhenNothingRunnable() {
        workflowService.registerDefinition(new WorkflowDefinition("w", List.of(
                new StepDefinition("a", 1, 1, List.of()),
                new StepDefinition("b", 1, 1, List.of("a"))
        )));
        WorkflowRun run = workflowService.startRun("w", "r");

        // Claim a so it is in_progress; nothing else is runnable.
        schedulerService.claimSteps(run.getRunId(), "w1", 10);

        List<SchedulerService.ClaimedStep> second = schedulerService.claimSteps(run.getRunId(), "w1", 10);
        assertThat(second).isEmpty();
    }

    // ----------------------------------------------------------------------
    // Retry behaviour
    // ----------------------------------------------------------------------

    @Test
    void failedStepWithAttemptsRemainingBecomesRunnable() {
        workflowService.registerDefinition(new WorkflowDefinition("w", List.of(
                new StepDefinition("a", 1, 3, List.of())
        )));
        WorkflowRun run = workflowService.startRun("w", "r");
        schedulerService.claimSteps(run.getRunId(), "w1", 1);
        schedulerService.completeStep(run.getRunId(), "a", "w1", 1, StepResult.FAIL);
        assertThat(run.getStep("a").getStatus()).isEqualTo(StepStatus.PENDING);

        List<SchedulerService.ClaimedStep> next = schedulerService.claimSteps(run.getRunId(), "w2", 1);
        assertThat(next).hasSize(1);
        assertThat(next.get(0).attemptNumber()).isEqualTo(2);
    }

    @Test
    void failedStepWithNoAttemptsRemainingBecomesFailed() {
        workflowService.registerDefinition(new WorkflowDefinition("w", List.of(
                new StepDefinition("a", 1, 1, List.of())
        )));
        WorkflowRun run = workflowService.startRun("w", "r");
        schedulerService.claimSteps(run.getRunId(), "w1", 1);
        schedulerService.completeStep(run.getRunId(), "a", "w1", 1, StepResult.FAIL);
        assertThat(run.getStep("a").getStatus()).isEqualTo(StepStatus.FAILED);
    }

    // ----------------------------------------------------------------------
    // Blocked propagation
    // ----------------------------------------------------------------------

    @Test
    void dependentOfFailedStepBecomesBlocked() {
        workflowService.registerDefinition(new WorkflowDefinition("w", List.of(
                new StepDefinition("a", 1, 1, List.of()),
                new StepDefinition("b", 1, 1, List.of("a"))
        )));
        WorkflowRun run = workflowService.startRun("w", "r");
        schedulerService.claimSteps(run.getRunId(), "w1", 1);
        schedulerService.completeStep(run.getRunId(), "a", "w1", 1, StepResult.FAIL);
        assertThat(run.getStep("b").getStatus()).isEqualTo(StepStatus.BLOCKED);
    }

    @Test
    void blockedPropagatesTransitively() {
        workflowService.registerDefinition(new WorkflowDefinition("w", List.of(
                new StepDefinition("a", 1, 1, List.of()),
                new StepDefinition("b", 1, 1, List.of("a")),
                new StepDefinition("c", 1, 1, List.of("b")),
                new StepDefinition("d", 1, 1, List.of("c"))
        )));
        WorkflowRun run = workflowService.startRun("w", "r");
        schedulerService.claimSteps(run.getRunId(), "w1", 1);
        schedulerService.completeStep(run.getRunId(), "a", "w1", 1, StepResult.FAIL);

        assertThat(run.getStep("b").getStatus()).isEqualTo(StepStatus.BLOCKED);
        assertThat(run.getStep("c").getStatus()).isEqualTo(StepStatus.BLOCKED);
        assertThat(run.getStep("d").getStatus()).isEqualTo(StepStatus.BLOCKED);
    }

    @Test
    void singleBlockedDependencyIsSufficientToBlock() {
        // d depends on both b (will fail) and c (will succeed).
        // d should still be blocked.
        workflowService.registerDefinition(new WorkflowDefinition("w", List.of(
                new StepDefinition("a", 1, 1, List.of()),
                new StepDefinition("b", 1, 1, List.of("a")),
                new StepDefinition("c", 1, 1, List.of("a")),
                new StepDefinition("d", 1, 1, List.of("b", "c"))
        )));
        WorkflowRun run = workflowService.startRun("w", "r");
        schedulerService.claimSteps(run.getRunId(), "w1", 1);
        schedulerService.completeStep(run.getRunId(), "a", "w1", 1, StepResult.SUCCESS);

        schedulerService.claimSteps(run.getRunId(), "w1", 2);
        schedulerService.completeStep(run.getRunId(), "b", "w1", 1, StepResult.FAIL);
        schedulerService.completeStep(run.getRunId(), "c", "w1", 1, StepResult.SUCCESS);

        assertThat(run.getStep("b").getStatus()).isEqualTo(StepStatus.FAILED);
        assertThat(run.getStep("c").getStatus()).isEqualTo(StepStatus.SUCCEEDED);
        assertThat(run.getStep("d").getStatus()).isEqualTo(StepStatus.BLOCKED);
    }

    // ----------------------------------------------------------------------
    // Completion validation
    // ----------------------------------------------------------------------

    @Test
    void completingNonClaimedStepThrows() {
        workflowService.registerDefinition(new WorkflowDefinition("w", List.of(
                new StepDefinition("a", 1, 1, List.of())
        )));
        WorkflowRun run = workflowService.startRun("w", "r");
        assertThatThrownBy(() -> schedulerService.completeStep(run.getRunId(), "a", "w1", 1, StepResult.SUCCESS))
                .isInstanceOf(InvalidStateException.class);
    }

    @Test
    void completingWithWrongWorkerThrows() {
        workflowService.registerDefinition(new WorkflowDefinition("w", List.of(
                new StepDefinition("a", 1, 1, List.of())
        )));
        WorkflowRun run = workflowService.startRun("w", "r");
        schedulerService.claimSteps(run.getRunId(), "worker-a", 1);
        assertThatThrownBy(() -> schedulerService.completeStep(run.getRunId(), "a", "worker-b", 1, StepResult.SUCCESS))
                .isInstanceOf(InvalidStateException.class)
                .hasMessageContaining("different worker");
    }

    @Test
    void completingWithStaleAttemptNumberThrows() {
        workflowService.registerDefinition(new WorkflowDefinition("w", List.of(
                new StepDefinition("a", 1, 2, List.of())
        )));
        WorkflowRun run = workflowService.startRun("w", "r");
        schedulerService.claimSteps(run.getRunId(), "w1", 1);
        schedulerService.completeStep(run.getRunId(), "a", "w1", 1, StepResult.FAIL);

        schedulerService.claimSteps(run.getRunId(), "w1", 1);
        // Current attempt is 2; passing 1 is stale.
        assertThatThrownBy(() -> schedulerService.completeStep(run.getRunId(), "a", "w1", 1, StepResult.SUCCESS))
                .isInstanceOf(InvalidStateException.class)
                .hasMessageContaining("Stale");
    }

    @Test
    void completingUnknownStepThrows() {
        workflowService.registerDefinition(new WorkflowDefinition("w", List.of(
                new StepDefinition("a", 1, 1, List.of())
        )));
        WorkflowRun run = workflowService.startRun("w", "r");
        assertThatThrownBy(() -> schedulerService.completeStep(run.getRunId(), "ghost", "w1", 1, StepResult.SUCCESS))
                .isInstanceOf(ValidationException.class);
    }

    // ----------------------------------------------------------------------
    // Input validation
    // ----------------------------------------------------------------------

    @Test
    void claimWithZeroMaxCountThrows() {
        workflowService.registerDefinition(new WorkflowDefinition("w", List.of(
                new StepDefinition("a", 1, 1, List.of())
        )));
        WorkflowRun run = workflowService.startRun("w", "r");
        assertThatThrownBy(() -> schedulerService.claimSteps(run.getRunId(), "w1", 0))
                .isInstanceOf(ValidationException.class);
    }

    @Test
    void claimWithBlankWorkerIdThrows() {
        workflowService.registerDefinition(new WorkflowDefinition("w", List.of(
                new StepDefinition("a", 1, 1, List.of())
        )));
        WorkflowRun run = workflowService.startRun("w", "r");
        assertThatThrownBy(() -> schedulerService.claimSteps(run.getRunId(), "  ", 1))
                .isInstanceOf(ValidationException.class);
    }

    // ----------------------------------------------------------------------
    // Run status derivation
    // ----------------------------------------------------------------------

    @Test
    void runStatusIsRunningInitially() {
        workflowService.registerDefinition(new WorkflowDefinition("w", List.of(
                new StepDefinition("a", 1, 1, List.of())
        )));
        WorkflowRun run = workflowService.startRun("w", "r");
        assertThat(schedulerService.deriveRunStatus(run)).isEqualTo(RunStatus.RUNNING);
    }

    @Test
    void runStatusIsSucceededWhenAllStepsSucceed() {
        workflowService.registerDefinition(new WorkflowDefinition("w", List.of(
                new StepDefinition("a", 1, 1, List.of())
        )));
        WorkflowRun run = workflowService.startRun("w", "r");
        schedulerService.claimSteps(run.getRunId(), "w1", 1);
        schedulerService.completeStep(run.getRunId(), "a", "w1", 1, StepResult.SUCCESS);
        assertThat(schedulerService.deriveRunStatus(run)).isEqualTo(RunStatus.SUCCEEDED);
    }

    @Test
    void runStatusIsFailedWhenSomeStepsFailAndNoneRunnable() {
        workflowService.registerDefinition(new WorkflowDefinition("w", List.of(
                new StepDefinition("a", 1, 1, List.of()),
                new StepDefinition("b", 1, 1, List.of("a"))
        )));
        WorkflowRun run = workflowService.startRun("w", "r");
        schedulerService.claimSteps(run.getRunId(), "w1", 1);
        schedulerService.completeStep(run.getRunId(), "a", "w1", 1, StepResult.FAIL);
        assertThat(schedulerService.deriveRunStatus(run)).isEqualTo(RunStatus.FAILED);
    }

    // ----------------------------------------------------------------------
    // Fixture
    // ----------------------------------------------------------------------

    private WorkflowDefinition modelPublishDefinition() {
        return new WorkflowDefinition("model-publish", List.of(
                new StepDefinition("load-model", 10, 1, List.of()),
                new StepDefinition("validate-schema", 9, 2, List.of("load-model")),
                new StepDefinition("write-audit", 5, 1, List.of("load-model")),
                new StepDefinition("persist-metadata", 8, 1, List.of("validate-schema")),
                new StepDefinition("publish-event", 7, 1, List.of("persist-metadata", "write-audit"))
        ));
    }
}
