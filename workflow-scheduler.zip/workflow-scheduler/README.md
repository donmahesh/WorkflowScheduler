# Persistent Workflow Scheduler

A small backend service that stores workflow definitions, coordinates which
steps are ready to execute, and tracks retries and final outcomes. Submitted
as the take-home exercise.

                  load-model
                  /        \
                 /          \
                v            v
       validate-schema    write-audit
                |              /
                v             /
       persist-metadata      /
                \           /
                 \         /
                  v       v
                 publish-event

---

## How to run

*** The code exercise has been written and tested on MS Windows Version 10.***

**Pre-requisites : Java 21+, Maven 3.9+.

1. Make sure Apache Maven 3.9+ installed on your machine
2. If Maven is not installed, downnload 3.9+ stable version from here https://maven.apache.org/download.cgi and unzip 
   the content to your local folder.
3. Configure System Environment variable to MAVEN_HOME under Sysytem Variables and point to your local folder where Maven is 
   installed/extracted
4. Make sure to add %MAVEN_HOME%\bin to PATH variable under Sysytem Variables
5. Similarly, if you do not have JDK installed, download JDK 21 or higher and install to your local folder
6. Make sure to add JAVA_HOME environment variable in System Environment Variable.


# Runing the tests

1. The tests can be run on Windows command line as follows (assuming Maven & Java installed and PATH includes Maven & JDK install locations)
  >mvn test

# To start the HTTP service (listens on :8080)

1. Extract the WorkflowScheduler.zip file content to a local folder on your machine
2. Go to Windows Command line 
3. Change directory to the root of the WorkflowScheduler project extracted in the step #1.
4. e.g. >cd C:\MaheshDongre\CodeExercise_updated\workflow-scheduler
5. Start the HTTP service:
   C:\MaheshDongre\CodeExercise_updated\workflow-scheduler>mvn spring-boot:run
6. Once the service fully up and running, the console should say 
   "Started WorkflowSchedulerApp...."

**Quick smoke test** once the service is running:

7. Once the service starts, perform the operations using the curl commands as follows: 

# 1. Register a workflow
curl -X POST http://localhost:8080/workflows \
  -H 'Content-Type: application/json' \
  -d '{
    "workflowName": "model-publish",
    "steps": [
      { "stepId": "load-model", "priority": 10, "maxAttempts": 1, "dependencies": [] },
      { "stepId": "validate-schema", "priority": 9, "maxAttempts": 2, "dependencies": ["load-model"] },
      { "stepId": "write-audit", "priority": 5, "maxAttempts": 1, "dependencies": ["load-model"] },
      { "stepId": "persist-metadata", "priority": 8, "maxAttempts": 1, "dependencies": ["validate-schema"] },
      { "stepId": "publish-event", "priority": 7, "maxAttempts": 1, "dependencies": ["persist-metadata", "write-audit"] }
    ]
  }'

# 2. Start a run
curl -X POST http://localhost:8080/runs \
  -H 'Content-Type: application/json' \
  -d '{ "workflowName": "model-publish", "requestId": "req-1001" }'

# 3. Claim Runnable steps (use the runId returned above)

curl -X POST http://localhost:8080/workers/claim \
  -H 'Content-Type: application/json' \
  -d '{ "runId": "<runId>", "workerId": "worker-a", "maxCount": 2 }'

# 4. Complete a step

**Note* Use the runId in the response for the Start Run operation as input to this operation

curl -X POST http://localhost:8080/workers/complete \
  -H 'Content-Type: application/json' \
  -d '{ "runId": "<runId>", "stepId": "load-model", "workerId": "worker-a", "attemptNumber": 1, "result": "success" }'
  
  
# 5. Claim Runnable steps again (use the runId returned above)

curl -X POST http://localhost:8080/workers/claim \
  -H 'Content-Type: application/json' \
  -d '{ "runId": "<runId>", "workerId": "worker-a", "maxCount": 2 }'

#6. Complete One Success and One Failure

**Note* Use the runId in the response for the Start Run operation as input to this operation

curl -X POST http://localhost:8080/workers/complete \
  -H 'Content-Type: application/json' \
  -d '{ "runId": "<runId>", "stepId": "load-model", "workerId": "worker-a", "attemptNumber": 1, "result": "success" }'
  
curl -X POST http://localhost:8080/workers/complete \
  -H 'Content-Type: application/json' \
  -d '{ "runId": "<runId>", "stepId": "load-model", "workerId": "worker-a", "attemptNumber": 1, "result": "fail" }'

# 7. Claim Runnable steps again (use the runId returned in #2 above)

curl -X POST http://localhost:8080/workers/claim \
  -H 'Content-Type: application/json' \
  -d '{ "runId": "<runId>", "workerId": "worker-b", "maxCount": 2 }'
  
# 8. Get the run summary (use the runId returned in #2 above)
curl http://localhost:8080/runs/<runId>


---

## Design overview

### Storage choice

**In-memory**, with every persistence operation routed through a repository
interface (`WorkflowDefinitionRepository`, `WorkflowRunRepository`). A
database-backed implementation can be dropped in by implementing those
interfaces — the service and domain layers do not change. See
[ARCHITECTURE.md](./ARCHITECTURE.md) for the specific migration sketch.

### Package layout

```
com.workflow.scheduler
├── WorkflowSchedulerApplication    Spring Boot entry point
├── api                             HTTP boundary (controllers + DTOs + mapper)
│   ├── dto/                        Request & response shapes
│   └── exception/                  Mapped to HTTP 400 / 404 / 409
├── domain                          Framework-free domain model
├── service                         Business logic & state machine
│   └── validation/                 Definition rules + cycle detection
└── repository                      Persistence boundary
    └── inmemory/                   The default implementation
```

### State machine (the heart of the solution)

```
      PENDING ─────► IN_PROGRESS ─────► SUCCEEDED
         │                │
         │                │ (fail, attempts remain)
         │                └──────────► PENDING
         │
         │ (fail, no attempts remain)
         └──────────► FAILED ───► propagates BLOCKED
                                   forward to dependents
      PENDING ─────► BLOCKED       (transitive)
```

A step is runnable only when every one of its dependencies is `SUCCEEDED`.
When a step reaches `FAILED` (final failure) the scheduler walks the
reverse-dependency graph and marks every still-`PENDING` dependent as
`BLOCKED`, repeating transitively.

### Claim ordering

When several steps are runnable, selection is deterministic:
`priority DESC`, then `stepId ASC`. Determinism matters for reproducible
tests and for operators reasoning about which worker will get what.

### Concurrency model

Every mutating operation on a run (`claimSteps`, `completeStep`) acquires
the lock on the specific `WorkflowRun` being modified. Concurrent operations
on **different** runs proceed in parallel; concurrent operations on the
**same** run are serialized. This narrows the hot path and avoids contention
between unrelated workflows.

A single global lock (`startRunLock` in `WorkflowService`) protects the
check-then-create sequence for idempotent run creation. Run creation is
low-frequency compared to the claim/complete path, so a single lock there
is fine.

### Idempotency

`startRun(workflowName, requestId)` is idempotent. The repository maintains
an index on `(workflowName, requestId) → runId`. Re-submitting the same
`requestId` returns the existing run instead of creating a new one.

---

## Assumptions

1. **A new definition replaces an existing one of the same name.** The
   exercise does not specify what happens on re-registration; the most
   useful default for a take-home is "last write wins." Existing runs
   continue to use the definition that was in place when they were started
   because each `WorkflowRun` captures its own step state at construction.
2. **No real concurrency across processes is required.** The exercise is
   explicit on this. In-process concurrency is handled correctly via
   `ReentrantLock`s. See [ARCHITECTURE.md](./ARCHITECTURE.md) for how this
   would evolve to multi-instance safety.
3. **`priority` is treated as an integer with no implied bounds.** Higher
   values mean higher priority.
4. **Run IDs are UUIDs** prefixed with `"run-"` for readability.
5. **Error response shape** is a small JSON object with `error` (short code)
   and `message` (human-readable). This keeps the API predictable without
   adopting any heavyweight error framework.

---

## Trade-offs

| Trade-off | What we did | Why | What we gave up |
|---|---|---|---|
| In-memory vs database | In-memory with pluggable repositories | Fastest to build; keeps focus on the domain | No crash recovery; state resets on restart |
| Per-run lock vs global lock | Per-run `ReentrantLock` | Allows parallel progress across runs | Slightly more code than one big `synchronized` |
| Spring Boot vs plain library | Spring Boot HTTP service | Natural shape for a backend platform service; low setup cost | Startup time; dependency weight |
| Blocked propagation eager vs lazy | Eager (propagate on failure) | Run summary always correct without recomputation | A tiny bit more work on failure |
| UUID IDs vs incrementing | UUID | Collision-free without coordination | Non-deterministic; tests rely on returned IDs |
| Separate DTOs vs domain-on-the-wire | Separate DTOs | Domain stays framework-free; API can evolve independently | Mapping code |

---

## Deliverables

- **Source code** — `src/main/java/`
- **Unit tests** — `src/test/java/`
  - `CycleDetectorTest` — exhaustive cycle shapes
  - `DefinitionValidatorTest` — every validation rule in the spec
  - `WorkflowServiceTest` — idempotency and lookup behavior
  - `SchedulerServiceTest` — state machine, claim ordering, retry, blocked propagation, completion validation, run status derivation
  - `EndToEndHttpTest` — full HTTP flow against MockMvc
- **README** — this file
- **ARCHITECTURE.md** — production evolution path (crash recovery, multi-instance safety, observability, audit, timeouts)

---

## Production evolution

The exercise's follow-up discussion topics are addressed in
[ARCHITECTURE.md](./ARCHITECTURE.md):

- Making `claimRunnableSteps` safe across multiple application instances
- Persisting state and recovering after a crash
- Observability, audit history, and replay
- Timeouts, stuck steps, and manual retries
